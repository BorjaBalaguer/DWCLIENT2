$(document).ready(function() {
    $("button").click(function(){
        $("#contenedor").load("Pagina.html");
        
    });
});
<?php
$param1 = $_POST["parametro1"];
$param2 = $_POST["parametro2"];

$result = "Los parámetros recibidos son: ".$param1. " y ".$param2;

echo $result;

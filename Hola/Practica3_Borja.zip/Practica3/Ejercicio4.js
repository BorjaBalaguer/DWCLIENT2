function contarImagenes() {
    alert(document.images.length);
    }
    
    function contarEnlaces() {
    alert(document.links.length);
    }
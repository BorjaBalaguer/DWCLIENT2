function colorAzul() {
    document.getElementById("color").style.backgroundColor = "blue";
}

function colorVerde() {
    document.getElementById("color").style.backgroundColor = "green"; 
}

function restablecerColor() {
    document.getElementById("color").style.backgroundColor = "";
}
verificar = function(a){
    var plantilla = /^[A-Z]{1}[0-9]{3}$/;
    if(plantilla.test(a)){
    alert("La clave es correcta");
    }else{

    }
}
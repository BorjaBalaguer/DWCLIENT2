<?php
$email=$_POST["enviarEmail"];
$telefono=$_POST["enviarTelefono"];
echo "El email es: " . $email;
echo "<br>";
echo "El telefono es: " . $telefono;
?>
function texto() {
  document.write("Borja es el mejor");
}

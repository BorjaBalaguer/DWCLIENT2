$.getJSON("https://restcountries.com/v2/region/europe", function(data){
    console.log(data);
});
<?php
  $fecha = date('Y-m-d H:i:s');
  echo $fecha;
?>
function IrGoogle() {
  window.open("https://www.google.es/?hl=ca")
}
document.write(location , "<br>");
document.write(location.pathname , "<br>");
document.write(location.protocol , "<br>");
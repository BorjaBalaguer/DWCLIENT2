function colorAzul() {
    var element = document.getElementById("myID");
    element.style.backgroundColor='blue';
}
function colorVerde() {
    var element = document.getElementById("myID");
    element.style.backgroundColor='green';
}
function colorRojo() {
    var element = document.getElementById("myID");
    element.style.backgroundColor='red';
}
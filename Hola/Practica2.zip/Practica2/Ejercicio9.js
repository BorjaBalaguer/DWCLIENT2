function AbrirVentana() {
    window.open("Ejercicio9Cerrar.html");
}
function CerrarVentana() {
    window.close();
}
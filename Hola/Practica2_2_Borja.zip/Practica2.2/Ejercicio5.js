setTimeout (function(){
    var ventana = window.open("","_self");
    ventana.document.write("<p>Pagina nueva</p>");}, 20000);


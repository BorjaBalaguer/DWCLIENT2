function enviar(){
    if (document.formulario.dni.value.length == 0) {
    alert("Introduce tu DNI");
    }
}
<?php
$time = time();
echo date("d-m-Y (H:i:s)", $time);
?>
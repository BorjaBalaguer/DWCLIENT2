window.onload=function(){
    
}

function aficiones(){
    var lista = document.getElementById('aficion')
    var indice = lista.selectedIndex;
    var option = lista.options[indice];
}